<template>
    <div>Comingsoon页面</div>
</template>
<script>
export default {
    name:'Comingsoon'
}
</script>